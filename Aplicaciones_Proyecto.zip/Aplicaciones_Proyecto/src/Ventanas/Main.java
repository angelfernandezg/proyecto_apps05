package Ventanas;

public class Main {

	//https://github.com/angelfernandezg/proyecto05.git
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		VentanaInicial v = new VentanaInicial();
		v.setVisible(true);
	}

}
